import pandas as pd
import numpy as np
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.metrics import classification_report, roc_auc_score

# Load data
purchases = pd.read_csv(r'C:\Users\halok\Downloads\customer_purchases (3).csv')
interests = pd.read_csv(r'C:\Users\halok\Downloads\customer_interests (2).csv')
demographics = pd.read_csv(r'C:\Users\halok\Downloads\customer_demographics.csv')
satisfaction = pd.read_csv(r'C:\Users\halok\Downloads\customer_satisfaction.csv')

# Merge data
data = pd.merge(purchases, demographics, on='cust_id', how='left')
data = pd.merge(data, interests, on='cust_id', how='left')
data = pd.merge(data, satisfaction, on='cust_id', how='left')

# Create target variable
purchase_counts = purchases['cust_id'].value_counts()
data['target'] = data['cust_id'].map(purchase_counts)
data['target'] = (data['target'] > 1).astype(int)  # 1 for multiple, 0 for single

# Handle missing values
# For numeric columns
numeric_cols = data.select_dtypes(include=[np.number]).drop(['cust_id', 'target'], axis=1, errors='ignore')
data[numeric_cols.columns] = numeric_cols.fillna(numeric_cols.median())

# For non-numeric columns
non_numeric_cols = data.select_dtypes(exclude=[np.number])
data[non_numeric_cols.columns] = non_numeric_cols.fillna('Unknown')

# Define preprocessor
# Ensure 'target' is not included in numerical_features
numerical_features = numeric_cols.columns.difference(['target'])
categorical_features = non_numeric_cols.columns

preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), numerical_features),
        ('cat', OneHotEncoder(handle_unknown='ignore'), categorical_features)
    ])

# Split data
X = data.drop(['target', 'cust_id'], axis=1)  # Drop the target and identifier
y = data['target']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build and train model
model = Pipeline(steps=[('preprocessor', preprocessor),
                        ('classifier', LogisticRegression(max_iter=1000))])

model.fit(X_train, y_train)

# Evaluate model
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))
print("ROC-AUC Score:", roc_auc_score(y_test, model.predict_proba(X_test)[:, 1]))
